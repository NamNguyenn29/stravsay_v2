﻿using behotel.DTO;
using behotel.Interface;
using behotel.Interfaces;
using behotel.Models;
using HotelBooking.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;

namespace behotel.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentService _paymentService;
        private readonly IPaymentWebhookEventService _webhookEventService;
        private readonly ILogger<PaymentController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;

        public PaymentController(
            IPaymentService paymentService,
            IPaymentWebhookEventService webhookEventService,
            ILogger<PaymentController> logger,
            IConfiguration configuration,
            IHttpClientFactory httpClientFactory)
        {
            _paymentService = paymentService;
            _webhookEventService = webhookEventService;
            _logger = logger;
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
        }

        /// <summary>
        /// Khởi tạo thanh toán MoMo
        /// </summary>
        [HttpPost("momo/create")]
        public async Task<IActionResult> CreateMomoPayment([FromBody] dynamic request)
        {
            try
            {
                var momo = _configuration.GetSection("MomoConfig");
                string endpoint = momo["Endpoint"];
                string partnerCode = momo["PartnerCode"];
                string accessKey = momo["AccessKey"];
                string secretKey = momo["SecretKey"];
                string returnUrl = momo["ReturnUrl"];
                string notifyUrl = momo["NotifyUrl"];
                string orderId = Guid.NewGuid().ToString();
                string requestId = Guid.NewGuid().ToString();
                string amount = Convert.ToString(request.amount);
                string orderInfo = "Payment for order " + orderId;
                string extraData = "";
                // Tạo chữ ký
                string rawHash = $"accessKey={accessKey}&amount={amount}&extraData={extraData}&orderId={orderId}&orderInfo={orderInfo}&partnerCode={partnerCode}&requestId={requestId}&returnUrl={returnUrl}&notifyUrl={notifyUrl}";
                string signature = ComputeHmacSHA256(rawHash, secretKey);
                var paymentRequest = new
                {
                    partnerCode,
                    accessKey,
                    requestId,
                    amount,
                    orderId,
                    orderInfo,
                    returnUrl,
                    notifyUrl,
                    extraData,
                    signature,
                    requestType = "captureMoMoWallet"
                };
                var client = _httpClientFactory.CreateClient();
                var response = await client.PostAsJsonAsync(endpoint, paymentRequest);
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(JsonConvert.DeserializeObject(responseContent));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating Momo payment");
                return StatusCode(500, new { message = "Internal Server Error", error = ex.Message });
            }
        }

        /// <summary>
        /// Nhận callback (IPN) từ Momo
        /// </summary>
        [HttpPost("momo/ipn")]
        public async Task<IActionResult> MomoIpnCallback([FromBody] dynamic payload, [FromHeader(Name = "X-Momo-Signature")] string signature)
        {
            string payloadString = JsonConvert.SerializeObject(payload);
            // Lưu webhook event
            var webhookEvent = await _webhookEventService.LogEventAsync("MOMO", payloadString, signature);
            // Xác minh chữ ký
            bool isValid = await _webhookEventService.ValidateSignatureAsync("MOMO", payloadString, signature);
            if (!isValid)
            {
                _logger.LogWarning("Invalid signature for Momo IPN");
                return BadRequest(new { message = "Invalid signature" });
            }
            // Xử lý thanh toán
            string orderId = payload.orderId;
            string resultCode = payload.resultCode;
            Guid paymentId = Guid.Parse(orderId);
            if (resultCode == "0")
            {
                await _paymentService.MarkAsPaidAsync(paymentId, payload.transId.ToString(), payloadString);
                _logger.LogInformation($"Payment {paymentId} marked as Paid");
            }
            else
            {
                await _paymentService.UpdateStatusAsync(paymentId, (int)PaymentStatus.Failed);
                _logger.LogInformation($"Payment {paymentId} marked as Failed");
            }
            return Ok(new { message = "IPN processed successfully" });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPayment(Guid id)
        {
            var payment = await _paymentService.GetByIdAsync(id);
            if (payment == null)
                return NotFound();

            return Ok(payment);
        }

        private string ComputeHmacSHA256(string message, string secretKey)
        {
            var encoding = new UTF8Encoding();
            byte[] keyByte = encoding.GetBytes(secretKey);
            byte[] messageBytes = encoding.GetBytes(message);
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                byte[] hashMessage = hmacsha256.ComputeHash(messageBytes);
                return BitConverter.ToString(hashMessage).Replace("-", "").ToLower();
            }
        }

        private enum PaymentStatus
        {
            Pending = 0,
            Paid = 1,
            Failed = 2
        }
    }
}
