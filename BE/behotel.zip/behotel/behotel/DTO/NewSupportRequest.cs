﻿namespace behotel.DTO
{
    public class NewSupportRequest
    {
        public string UserEmail { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
