﻿namespace behotel.DTO
{
    public class RoomTypeDTO
    {
        public Guid Id { get; set; }
        public required string TypeName { get; set; }
    }
}
