﻿namespace behotel.DTO
{
    public class UserRegister
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
