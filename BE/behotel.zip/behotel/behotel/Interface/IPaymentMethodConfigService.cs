﻿using behotel.DTO;

namespace behotel.Interfaces
{
    /// <summary>
    /// Service quản lý cấu hình chi tiết cho từng phương thức thanh toán (MoMo, ZaloPay, BankTransfer, v.v.).
    /// </summary>
    public interface IPaymentMethodConfigService
    {
        /// <summary>
        /// Lấy cấu hình chi tiết theo mã phương thức (ví dụ: "MOMO", "ZALOPAY").
        /// </summary>
        Task<PaymentMethodConfigDTO?> GetByMethodCodeAsync(string methodCode);

        /// <summary>
        /// Lấy cấu hình chi tiết theo ID.
        /// </summary>
        Task<PaymentMethodConfigDTO?> GetByIdAsync(Guid configId);

        /// <summary>
        /// Tạo mới hoặc cập nhật cấu hình cho phương thức thanh toán.
        /// </summary>
        Task<bool> CreateOrUpdateAsync(PaymentMethodConfigDTO config);

        /// <summary>
        /// Xóa cấu hình theo ID (nếu cần, ví dụ khi tắt phương thức thanh toán).
        /// </summary>
        Task<bool> DeleteAsync(Guid configId);

        /// <summary>
        /// Lấy danh sách tất cả cấu hình (dùng trong trang admin).
        /// </summary>
        Task<IEnumerable<PaymentMethodConfigDTO>> GetAllAsync();

        /// <summary>
        /// Trả về cấu hình đã giải mã (nếu API key/secret được mã hoá).
        /// Dùng khi cần gọi API thật đến MoMo hoặc ZaloPay.
        /// </summary>
        Task<PaymentMethodConfigDTO?> GetDecryptedConfigAsync(Guid paymentMethodId);
    }
}
