﻿using behotel.DTO;

public interface IPaymentMethodService
{
    // Lấy tất cả phương thức active để hiển thị cho người dùng
    Task<IEnumerable<PaymentMethodDTO>> GetAllActiveAsync();

    // Lấy chi tiết 1 phương thức theo ID
    Task<PaymentMethodDTO?> GetByIdAsync(Guid id);

    // Bật phương thức thanh toán (admin)
    Task<bool> EnableAsync(Guid id);

    // Tắt phương thức thanh toán (admin)
    Task<bool> DisableAsync(Guid id);
}
