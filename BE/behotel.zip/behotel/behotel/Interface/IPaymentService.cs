﻿using behotel.DTO;
using HotelBooking.Models;

public interface IPaymentService
{
    // Tạo mới một giao dịch thanh toán
    Task<PaymentDTO> CreateAsync(PaymentDTO payment);

    // Lấy chi tiết một payment theo ID
    Task<PaymentDTO?> GetByIdAsync(Guid paymentId);

    // Lấy tất cả payment theo booking ID
    Task<IEnumerable<PaymentDTO>> GetByBookingIdAsync(Guid bookingId);

    // Cập nhật trạng thái thanh toán (ví dụ: Paid, Failed, Canceled)
    Task<bool> UpdateStatusAsync(Guid paymentId, int status);

    // Đánh dấu giao dịch đã thanh toán thành công (ví dụ: tại khách sạn hoặc sau webhook)
    Task<bool> MarkAsPaidAsync(Guid paymentId, string? providerRef, string? responsePayload);

    // Xóa hoặc hủy thanh toán nếu vẫn còn pending
    Task<bool> CancelAsync(Guid paymentId);

}
