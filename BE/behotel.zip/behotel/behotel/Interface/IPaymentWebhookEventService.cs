﻿using behotel.DTO;

namespace behotel.Interfaces
{
    /// <summary>
    /// Service dùng để ghi nhận và xử lý các sự kiện webhook từ nhà cung cấp thanh toán (như MoMo, ZaloPay).
    /// </summary>
    public interface IPaymentWebhookEventService
    {
        /// <summary>
        /// Ghi nhận một webhook mới từ nhà cung cấp (lưu payload, chữ ký, thời gian nhận).
        /// </summary>
        Task<PaymentWebhookEventDTO> LogEventAsync(string provider, string payload, string? signature);

        /// <summary>
        /// Xác minh chữ ký (signature) của webhook có hợp lệ hay không.
        /// </summary>
        Task<bool> ValidateSignatureAsync(string provider, string payload, string signature);

        /// <summary>
        /// Xử lý webhook đã ghi nhận (cập nhật trạng thái Payment, lưu kết quả xử lý).
        /// </summary>
        Task<bool> ProcessEventAsync(Guid eventId);

        /// <summary>
        /// Lấy danh sách sự kiện webhook chưa được xử lý.
        /// </summary>
        Task<IEnumerable<PaymentWebhookEventDTO>> GetUnprocessedEventsAsync();

        /// <summary>
        /// Lấy chi tiết một webhook theo ID.
        /// </summary>
        Task<PaymentWebhookEventDTO?> GetByIdAsync(Guid eventId);
    }
}
