﻿public interface IPaymentWebhookService
{
    // Xử lý webhook (payload = nội dung JSON nhận được)
    Task<bool> HandleWebhookAsync(string providerCode, string payload, string? signature);

    // Lưu log webhook vào DB (tùy chọn)
    Task<bool> SaveEventAsync(string providerCode, string payload, bool processed, string? errorMessage);
}
