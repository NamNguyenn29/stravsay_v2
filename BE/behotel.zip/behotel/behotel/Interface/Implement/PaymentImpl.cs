﻿using behotel.DTO;
using behotel.Interface;
using behotel.Models;
using HotelBooking.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace behotel.Interface.Implement
{
    public class PaymentImpl : IPaymentService
    {
        private readonly HotelManagementContext _context;
        private readonly IConfiguration _config;
        private readonly ILogger<PaymentImpl> _logger;
        private readonly HttpClient _httpClient;

        public PaymentImpl(
            HotelManagementContext context,
            IConfiguration config,
            ILogger<PaymentImpl> logger,
            IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _config = config;
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
        }

        // ================================
        // CREATE PAYMENT
        // ================================
        public async Task<PaymentDTO> CreateAsync(PaymentDTO dto)
        {
            if (dto == null)
                throw new ArgumentNullException(nameof(dto));

            var paymentMethod = await _context.PaymentMethods
                .FirstOrDefaultAsync(m => m.PaymentMethodID == dto.PaymentMethodID);

            if (paymentMethod == null)
                throw new Exception("Phương thức thanh toán không tồn tại.");

            var payment = new Payment
            {
                PaymentID = Guid.NewGuid(),
                BookingID = dto.BookingID,
                PaymentMethodID = dto.PaymentMethodID,
                Amount = dto.Amount,
                Status = 0, // Pending
                CreatedDate = DateTime.UtcNow
            };

            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            // Nếu là MoMo → tạo link thanh toán
            if (paymentMethod.Code.Equals("MOMO", StringComparison.OrdinalIgnoreCase))
            {
                var payUrl = await CreateMomoPaymentUrl(payment);
                dto.ProviderTransactionRef = null;
                dto.ResponsePayload = payUrl;
                dto.Status = 0;
                dto.CreatedDate = payment.CreatedDate;
                return dto;
            }
            // ZaloPay (placeholder)
            else if (paymentMethod.Code.Equals("ZALOPAY", StringComparison.OrdinalIgnoreCase))
            {
                dto.ResponsePayload = "ZaloPay integration chưa được cấu hình.";
                return dto;
            }
            // Bank transfer → chỉ lưu thông tin chờ chuyển khoản
            else if (paymentMethod.Code.Equals("BANK_TRANSFER", StringComparison.OrdinalIgnoreCase))
            {
                dto.ResponsePayload = "Vui lòng chuyển khoản theo thông tin ngân hàng.";
                return dto;
            }
            // Thanh toán tại khách sạn
            else if (paymentMethod.Code.Equals("PAY_ON_ARRIVAL", StringComparison.OrdinalIgnoreCase))
            {
                dto.ResponsePayload = "Thanh toán tại quầy lễ tân khi đến khách sạn.";
                return dto;
            }

            return dto;
        }

        // ================================
        // TẠO LINK THANH TOÁN MOMO
        // ================================
        private async Task<string> CreateMomoPaymentUrl(Payment payment)
        {
            try
            {
                var momoSection = _config.GetSection("MomoConfig");
                string endpoint = momoSection["Endpoint"];
                string partnerCode = momoSection["PartnerCode"];
                string accessKey = momoSection["AccessKey"];
                string secretKey = momoSection["SecretKey"];
                string redirectUrl = momoSection["RedirectUrl"];
                string ipnUrl = momoSection["IpnUrl"];
                string requestType = "captureWallet";

                string orderId = Guid.NewGuid().ToString();
                string requestId = DateTime.UtcNow.Ticks.ToString();
                string orderInfo = $"Thanh toan don hang {payment.BookingID}";
                string amount = ((int)payment.Amount).ToString();
                string extraData = "";

                string rawHash =
                    "partnerCode=" + partnerCode +
                    "&accessKey=" + accessKey +
                    "&requestId=" + requestId +
                    "&amount=" + amount +
                    "&orderId=" + orderId +
                    "&orderInfo=" + orderInfo +
                    "&returnUrl=" + redirectUrl +
                    "&notifyUrl=" + ipnUrl +
                    "&extraData=" + extraData;

                string signature = ComputeHmacSha256(rawHash, secretKey);

                var requestBody = new
                {
                    partnerCode,
                    accessKey,
                    requestId,
                    amount,
                    orderId,
                    orderInfo,
                    returnUrl = redirectUrl,
                    notifyUrl = ipnUrl,
                    extraData,
                    requestType,
                    signature,
                    lang = "vi"
                };

                var jsonBody = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(endpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                var momoResponse = JsonConvert.DeserializeObject<MomoResponse>(responseContent);
                return momoResponse?.PayUrl ?? "Không tạo được link thanh toán.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lỗi khi tạo link thanh toán MoMo");
                return "Lỗi khi tạo link thanh toán MoMo.";
            }
        }

        private string ComputeHmacSha256(string data, string key)
        {
            using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key)))
            {
                byte[] hashValue = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
                return BitConverter.ToString(hashValue).Replace("-", "").ToLower();
            }
        }

        // ================================
        // LẤY PAYMENT THEO ID
        // ================================
        public async Task<PaymentDTO?> GetByIdAsync(Guid paymentId)
        {
            var payment = await _context.Payments.FindAsync(paymentId);
            if (payment == null) return null;

            return new PaymentDTO
            {
                PaymentID = payment.PaymentID,
                BookingID = payment.BookingID,
                PaymentMethodID = payment.PaymentMethodID,
                Amount = payment.Amount,
                Status = payment.Status,
                CreatedDate = payment.CreatedDate,
                PaidAt = payment.PaidAt,
                ProviderTransactionRef = payment.ProviderTransactionRef,
                ResponsePayload = payment.ResponsePayload
            };
        }

        // ================================
        // LẤY PAYMENT THEO BOOKING ID
        // ================================
        public async Task<IEnumerable<PaymentDTO>> GetByBookingIdAsync(Guid bookingId)
        {
            return await _context.Payments
                .Where(p => p.BookingID == bookingId)
                .Select(p => new PaymentDTO
                {
                    PaymentID = p.PaymentID,
                    BookingID = p.BookingID,
                    PaymentMethodID = p.PaymentMethodID,
                    Amount = p.Amount,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    PaidAt = p.PaidAt,
                    ProviderTransactionRef = p.ProviderTransactionRef
                })
                .ToListAsync();
        }

        // ================================
        // CẬP NHẬT TRẠNG THÁI
        // ================================
        public async Task<bool> UpdateStatusAsync(Guid paymentId, int status)
        {
            var payment = await _context.Payments.FindAsync(paymentId);
            if (payment == null) return false;

            payment.Status = status;
            await _context.SaveChangesAsync();
            return true;
        }

        // ================================
        // ĐÁNH DẤU ĐÃ THANH TOÁN
        // ================================
        public async Task<bool> MarkAsPaidAsync(Guid paymentId, string? providerRef, string? responsePayload)
        {
            var payment = await _context.Payments.FindAsync(paymentId);
            if (payment == null) return false;

            payment.Status = 1; // Paid
            payment.PaidAt = DateTime.UtcNow;
            payment.ProviderTransactionRef = providerRef;
            payment.ResponsePayload = responsePayload;

            await _context.SaveChangesAsync();
            return true;
        }

        // ================================
        // HỦY PAYMENT
        // ================================
        public async Task<bool> CancelAsync(Guid paymentId)
        {
            var payment = await _context.Payments.FindAsync(paymentId);
            if (payment == null) return false;

            if (payment.Status == 0) // Pending
            {
                payment.Status = 2; // Canceled
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }

        // ================================
        // NỘI BỘ: LỚP MAPPING MOMO RESPONSE
        // ================================
        private class MomoResponse
        {
            [JsonProperty("payUrl")]
            public string PayUrl { get; set; }
        }
    }
}
