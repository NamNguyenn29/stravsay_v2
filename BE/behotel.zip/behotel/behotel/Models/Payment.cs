﻿using System;

namespace HotelBooking.Models
{
    public class Payment
    {
        public Guid PaymentID { get; set; }
        public Guid BookingID { get; set; }
        public Guid PaymentMethodID { get; set; }
        public decimal Amount { get; set; }
        public DateTime? PaidAt { get; set; }
        public int Status { get; set; }
        public DateTime CreatedDate { get; set; }

        // Optional / new fields from previous discussions
        public string? ProviderTransactionRef { get; set; }
        public string? MerchantReference { get; set; }
        public decimal? Fee { get; set; }
        public string? ResponsePayload { get; set; }

        // Navigation properties (optional if using EF Core)
        public PaymentMethod? PaymentMethod { get; set; }
    }

}